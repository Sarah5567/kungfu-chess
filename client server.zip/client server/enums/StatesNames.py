from enum import Enum

class StatesNames(Enum):
    IDLE = "idle"
    MOVE = "move"
    LONG_REST = "long_rest"
    JUMP = "jump"
    SHORT_REST = "short_rest"